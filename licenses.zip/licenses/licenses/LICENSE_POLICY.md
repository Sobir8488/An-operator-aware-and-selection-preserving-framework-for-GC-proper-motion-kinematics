# Proposed mixed-license policy

This package is prepared for the following release policy:

- Original OPERA-GC software and scripts: **MIT**.
- Original documentation, manuscript assets, figures, and derived tables: **CC BY 4.0**.
- Third-party source products: their original licenses and citation requirements.

**Author approval is required before publication.** The files are named
`PROPOSED_*` intentionally. After approval, remove the `PROPOSED_` prefix’ chosen terms.
