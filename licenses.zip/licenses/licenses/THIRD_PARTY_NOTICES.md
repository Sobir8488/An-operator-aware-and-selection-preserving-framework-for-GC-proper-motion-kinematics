# Third-party notices

The release uses or derives products from:

- Hubble Space Telescope Atlases of Cluster Kinematics (HACKS), DOI
  `10.17909/jpfd-2m08`, released under the source archive's stated terms.
- Gaia EDR3 globular-cluster products, DOI `10.5281/zenodo.4891252`, released
  under the source record's stated terms.
- Elsevier `elsarticle` class and bibliography style, included solely to make
  the manuscript source compilable; their original distribution terms apply.
- NumPy, SciPy, pandas, Matplotlib, Astropy, pytest, and other dependencies,
  each under its own upstream license.

No third-party product is relicensed by OPERA-GC. Exact provenance and source
identifiers are retained in the stage manifests and attribution files.
