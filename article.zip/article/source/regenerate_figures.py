from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'figure_source_data'
FIGURES = ROOT / 'figures'
FIGURES.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.size': 18,
    'axes.labelsize': 20,
    'axes.titlesize': 20,
    'xtick.labelsize': 16,
    'ytick.labelsize': 16,
    'legend.fontsize': 15,
    'figure.titlesize': 22,
    'lines.linewidth': 2.2,
    'lines.markersize': 8,
    'axes.linewidth': 1.2,
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

BLUE = '#0072B2'
ORANGE = '#D55E00'
GREEN = '#009E73'
PURPLE = '#CC79A7'
DARK = '#222222'
GREY = '#6F6F6F'


def locate(name: str) -> Path:
    matches = list(DATA.rglob(name))
    if len(matches) != 1:
        raise RuntimeError(f'{name}: expected one match, found {matches}')
    return matches[0]


def save(fig: plt.Figure, stem: str, *, png_dpi: int = 450) -> None:
    fig.savefig(FIGURES / f'{stem}.pdf', bbox_inches='tight')
    fig.savefig(FIGURES / f'{stem}.png', dpi=png_dpi, bbox_inches='tight')
    plt.close(fig)


def panel_label(ax: plt.Axes, letter: str, *, x: float = 0.025, y: float = 0.96, ha: str = 'left') -> None:
    ax.text(
        x, y, letter, transform=ax.transAxes,
        ha=ha, va='top', fontsize=20, fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor='none', alpha=0.9),
    )


def architecture() -> None:
    # A compact 2x2 workflow keeps all labels legible at two-column width.
    fig, ax = plt.subplots(figsize=(12.8, 8.2))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    positions = {
        'inputs': (0.055, 0.56),
        'registry': (0.535, 0.56),
        'outputs': (0.055, 0.095),
        'validation': (0.535, 0.095),
    }
    width, height = 0.405, 0.32
    blocks = {
        'inputs': (
            'Heterogeneous inputs',
            'HST relative PM products\nGaia absolute star-level PMs\nselection, covariance, radial support',
        ),
        'registry': (
            'Operator registry',
            r'$\mathcal{O}_j=\{q,p,s,K,w,C,r,\eta,\pi\}$' + '\nversioned semantics and provenance\nchecksums, aliases, explicit unknowns',
        ),
        'validation': (
            'Validation engine',
            'compatibility and support gates\nselection envelopes and same-star tests\ncovariance, contamination, injections',
        ),
        'outputs': (
            'Claim-controlled outputs',
            'operator-specific likelihoods\nmachine-readable ledgers and failures\nreproducible tables, figures, archives',
        ),
    }

    for key in ['inputs', 'registry', 'validation', 'outputs']:
        x, y = positions[key]
        heading, body = blocks[key]
        box = FancyBboxPatch(
            (x, y), width, height,
            boxstyle='round,pad=0.015,rounding_size=0.018',
            linewidth=2.0, edgecolor=DARK, facecolor='white'
        )
        ax.add_patch(box)
        ax.text(x + width / 2, y + height * 0.75, heading,
                ha='center', va='center', fontsize=21, fontweight='bold')
        ax.text(x + width / 2, y + height * 0.38, body,
                ha='center', va='center', fontsize=15.5, linespacing=1.35)

    arrows = [
        ((0.465, 0.72), (0.525, 0.72)),
        ((0.738, 0.55), (0.738, 0.43)),
        ((0.525, 0.255), (0.465, 0.255)),
    ]
    for start_xy, end_xy in arrows:
        ax.add_patch(FancyArrowPatch(
            start_xy, end_xy, arrowstyle='-|>', mutation_scale=24,
            linewidth=2.2, color=BLUE
        ))

    save(fig, 'fig01_architecture')
    # Graphical abstract uses the same clean vector composition.
    fig, ax = plt.subplots(figsize=(12.8, 8.2))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    for key in ['inputs', 'registry', 'validation', 'outputs']:
        x, y = positions[key]
        heading, body = blocks[key]
        box = FancyBboxPatch((x, y), width, height,
                             boxstyle='round,pad=0.015,rounding_size=0.018',
                             linewidth=2.0, edgecolor=DARK, facecolor='white')
        ax.add_patch(box)
        ax.text(x + width / 2, y + height * 0.75, heading,
                ha='center', va='center', fontsize=21, fontweight='bold')
        ax.text(x + width / 2, y + height * 0.38, body,
                ha='center', va='center', fontsize=15.5, linespacing=1.35)
    for start_xy, end_xy in arrows:
        ax.add_patch(FancyArrowPatch(start_xy, end_xy, arrowstyle='-|>',
                                     mutation_scale=24, linewidth=2.2, color=BLUE))
    fig.savefig(FIGURES / 'graphical_abstract.pdf', bbox_inches='tight')
    fig.savefig(FIGURES / 'graphical_abstract.png', dpi=450, bbox_inches='tight')
    plt.close(fig)


def radial_support() -> None:
    df = pd.read_csv(locate('multicluster_radial_coverage.csv'))
    df['label'] = df['cluster'].str.replace('_', ' ', regex=False)
    df = df.iloc[::-1].reset_index(drop=True)
    y = np.arange(len(df))
    fig, ax = plt.subplots(figsize=(12.2, 8.8), constrained_layout=True)
    offset = 0.12
    for idx, row in df.iterrows():
        ax.plot([row.hacks_min_arcsec, row.hacks_max_arcsec], [idx-offset, idx-offset],
                color=BLUE, linewidth=5.0, solid_capstyle='butt')
        ax.plot([row.gaia_primary_min_arcsec, row.gaia_primary_max_arcsec], [idx+offset, idx+offset],
                color=ORANGE, linewidth=4.0, solid_capstyle='butt')
    ax.plot([], [], color=BLUE, linewidth=5.0, label='HACKS support')
    ax.plot([], [], color=ORANGE, linewidth=4.0, label='Gaia primary support')
    ax.set_xscale('log')
    ax.set_yticks(y, df['label'])
    ax.set_xlabel('Projected radius [arcsec]')
    ax.set_ylabel('')
    ax.grid(axis='x', alpha=0.22, linewidth=0.8)
    ax.legend(loc='upper right', frameon=True)
    ax.margins(y=0.06)
    save(fig, 'fig_multicluster_radial_support')


def outer_slopes() -> None:
    df = pd.read_csv(locate('gaia_starlevel_likelihood_fits.csv'))
    order = df[df.component.eq('radial')]['cluster'].tolist()[::-1]
    y = np.arange(len(order))
    fig, ax = plt.subplots(figsize=(11.4, 8.4), constrained_layout=True)
    for comp, color, marker, dy, label in [
        ('radial', BLUE, 'o', -0.12, 'Radial component'),
        ('tangential', ORANGE, 's', 0.12, 'Tangential component'),
    ]:
        d = df[df.component.eq(comp)].set_index('cluster').loc[order]
        ax.errorbar(d['gamma'], y + dy, xerr=d['gamma_err'], fmt=marker,
                    color=color, ecolor=color, capsize=4, elinewidth=2.0,
                    markeredgecolor='white', markeredgewidth=0.7, label=label)
    ax.axvline(0, color=GREY, linestyle='--', linewidth=1.5)
    ax.set_yticks(y, [c.replace('_', ' ') for c in order])
    ax.set_xlabel(r'Outer-field dispersion slope $\gamma$')
    ax.set_ylabel('')
    ax.grid(axis='x', alpha=0.22, linewidth=0.8)
    ax.legend(loc='lower left', frameon=True)
    save(fig, 'fig_gaia_outer_slopes')


def selection_and_match() -> None:
    ker = pd.read_csv(locate('kernel_weighted_selection_stress.csv'))
    cross = pd.read_csv(locate('ngc6397_crossmatch_radius_ladder.csv'))
    fig, axes = plt.subplots(1, 2, figsize=(15.6, 6.2), constrained_layout=True)
    ax = axes[0]
    for comp, color, marker, label in [
        ('radial', BLUE, 'o', 'Radial'),
        ('tangential', ORANGE, 's', 'Tangential'),
    ]:
        d = ker[ker.component.eq(comp)].sort_values('kernel_centre_g')
        ax.errorbar(d.kernel_centre_g, d.scale, yerr=d.scale_err, fmt=marker, linestyle='none',
                    color=color, capsize=4, markeredgecolor='white', markeredgewidth=0.6,
                    label=label)
    ax.axhline(1.0, color=GREY, linestyle='--', linewidth=1.5)
    ax.set_xlabel('Gaia $G$ kernel centre [mag]')
    ax.set_ylabel('Gaia/HACKS scale')
    ax.legend(loc='upper left', frameon=True)
    ax.grid(alpha=0.2, linewidth=0.8)
    panel_label(ax, 'a', x=0.975, ha='right')

    ax = axes[1]
    ax.plot(cross.match_radius_arcsec, cross.mutual_unique_matches, 'o-', color=BLUE)
    ax.set_xlabel('Match radius [arcsec]')
    ax.set_ylabel('Mutual unique matches')
    ax.set_ylim(214.8, 215.2)
    ax.set_yticks([215])
    ax.grid(alpha=0.2, linewidth=0.8)
    panel_label(ax, 'b')
    save(fig, 'fig_ngc6397_selection_and_match')


def envelope() -> None:
    var = pd.read_csv(locate('selection_envelope_variants.csv'))
    same = pd.read_csv(locate('selection_matched_same_star_comparison.csv'))
    report = json.loads(locate('stage2e_report.json').read_text())
    anchor_id = int(report['predeclared_anchor_variant_id'])
    anchor = var[var.variant_id.eq(anchor_id)].iloc[0]

    fig, axes = plt.subplots(1, 2, figsize=(15.6, 6.4), constrained_layout=True)
    ax = axes[0]
    plausible = var.published_count_within_20pct.astype(bool)
    ax.scatter(var.loc[~plausible, 'n_in_published_support'],
               var.loc[~plausible, 'profile_reduced_chi2'],
               s=34, alpha=0.62, color=BLUE, edgecolors='none', label='Outside count band')
    ax.scatter(var.loc[plausible, 'n_in_published_support'],
               var.loc[plausible, 'profile_reduced_chi2'],
               s=44, alpha=0.80, color=GREEN, edgecolors='none', label='Within 20% of 617')
    ax.scatter([anchor.n_in_published_support], [anchor.profile_reduced_chi2],
               marker='*', s=260, color=ORANGE, edgecolors=DARK, linewidths=0.8,
               label='Predeclared anchor', zorder=5)
    ax.axhline(2.5, color=GREY, linestyle='--', linewidth=1.5)
    ax.axvline(617, color=GREY, linestyle=':', linewidth=1.5)
    ax.set_xlabel('Selected stars in published support')
    ax.set_ylabel(r'Profile reduced $\chi^2$')
    ax.legend(loc='lower right', frameon=True, fontsize=13)
    ax.grid(alpha=0.18, linewidth=0.8)
    panel_label(ax, 'a')

    ax = axes[1]
    available = same[same.fit_available.astype(bool)]
    for comp, color, marker, label in [
        ('radial', BLUE, 'o', 'Radial'),
        ('tangential', ORANGE, 's', 'Tangential'),
    ]:
        d = available[available.component.eq(comp)]
        ax.scatter(d.n_same_stars, d.gaia_over_hst_scale, s=37, alpha=0.72,
                   color=color, marker=marker, edgecolors='none', label=label)
    ax.axhline(1.0, color=GREY, linestyle='--', linewidth=1.5)
    ax.set_xlabel('Selection-matched stars')
    ax.set_ylabel('Gaia/HST intrinsic-dispersion scale')
    ax.legend(loc='upper right', frameon=True)
    ax.grid(alpha=0.18, linewidth=0.8)
    panel_label(ax, 'b')
    save(fig, 'fig_selection_envelope')


def anchor_profiles() -> None:
    prof = pd.read_csv(locate('selection_envelope_profile_reconstructions.csv'))
    report = json.loads(locate('stage2e_report.json').read_text())
    anchor_id = int(report['predeclared_anchor_variant_id'])
    d = prof[prof.variant_id.eq(anchor_id)].copy()
    fig, axes = plt.subplots(1, 2, figsize=(15.6, 6.2), constrained_layout=True, sharex=True)
    specifications = [
        ('rad', r'$\sigma_R$ [mas yr$^{-1}$]', 'Radial'),
        ('tan', r'$\sigma_T$ [mas yr$^{-1}$]', 'Tangential'),
    ]
    for ax, (tag, ylabel, label) in zip(axes, specifications):
        ax.errorbar(d.published_radius_arcsec, d[f'sigma_{tag}_published'],
                    yerr=d[f'sigma_{tag}_published_err'], fmt='o-', color=BLUE,
                    capsize=4, label='Published HACKS')
        ax.errorbar(d.published_radius_arcsec, d[f'sigma_{tag}_reconstructed'],
                    yerr=d[f'sigma_{tag}_reconstructed_err'], fmt='s--', color=ORANGE,
                    capsize=4, label='Reconstructed anchor')
        ax.set_xscale('log')
        ax.set_xlabel('Projected radius [arcsec]')
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.2, linewidth=0.8)
        ax.legend(loc='upper right', frameon=True, fontsize=13)
    panel_label(axes[0], 'a')
    panel_label(axes[1], 'b')
    save(fig, 'fig_anchor_profiles')


def main() -> None:
    architecture()
    radial_support()
    outer_slopes()
    selection_and_match()
    envelope()
    anchor_profiles()
    print('Figures regenerated in', FIGURES)


if __name__ == '__main__':
    main()
