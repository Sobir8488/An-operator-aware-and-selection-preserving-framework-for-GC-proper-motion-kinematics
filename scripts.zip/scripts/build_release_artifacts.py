#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, shutil, zipfile

root=Path(__file__).resolve().parents[1]
version=(root/'VERSION').read_text(encoding='utf-8').strip()
exclude={'SHA256SUMS.txt','MANIFEST.csv'}
rows=[]
for p in sorted(root.rglob('*')):
    if not p.is_file() or p.relative_to(root).as_posix() in exclude:
        continue
    rel=p.relative_to(root).as_posix()
    rows.append((rel,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()))
with (root/'MANIFEST.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['path','size_bytes','sha256']); w.writerows(rows)
(root/'SHA256SUMS.txt').write_text(
    ''.join(f'{h}  {rel}\n' for rel,_,h in rows),encoding='utf-8'
)

release_zip=root.parent/(root.name+'.zip')
if release_zip.exists(): release_zip.unlink()
with zipfile.ZipFile(release_zip,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file(): z.write(p,Path(root.name)/p.relative_to(root))

upload_dir=root.parent/f'opera_gc_zenodo_upload_set_v{version.replace(".","_")}'
if upload_dir.exists(): shutil.rmtree(upload_dir)
upload_dir.mkdir(parents=True)
for src,dst in [
    (release_zip,release_zip.name),
    (root/'article'/f'OPERA_GC_preprint_v{version}.pdf',f'OPERA_GC_preprint_v{version}.pdf'),
    (root/'README.md','README.md'),
    (root/'CITATION.cff','CITATION.cff'),
    (root/'.zenodo.json','.zenodo.json'),
    (root/'SHA256SUMS.txt','SHA256SUMS_RELEASE_CONTENTS.txt'),
    (root/'metadata/ZENODO_UPLOAD_CHECKLIST.md','ZENODO_UPLOAD_CHECKLIST.md'),
    (root/'metadata/ZENODO_FORM_VALUES.md','ZENODO_FORM_VALUES.md'),
]:
    shutil.copy2(src,upload_dir/dst)
(upload_dir/'UPLOAD_THESE_FILES.txt').write_text(
    'Upload these files individually to the Zenodo draft after the reserved DOI has been inserted and the artifacts rebuilt.\n',
    encoding='utf-8'
)
upload_rows=[]
for p in sorted(upload_dir.iterdir()):
    if p.is_file() and p.name!='SHA256SUMS.txt':
        upload_rows.append((p.name,hashlib.sha256(p.read_bytes()).hexdigest()))
(upload_dir/'SHA256SUMS.txt').write_text(
    ''.join(f'{h}  {name}\n' for name,h in upload_rows),encoding='utf-8'
)
upload_zip=root.parent/(upload_dir.name+'.zip')
if upload_zip.exists(): upload_zip.unlink()
with zipfile.ZipFile(upload_zip,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
    for p in sorted(upload_dir.iterdir()):
        if p.is_file(): z.write(p,Path(upload_dir.name)/p.name)
print(release_zip)
print(upload_zip)
