#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

if len(sys.argv) != 2 or not re.fullmatch(r"10\.5281/zenodo\.\d+", sys.argv[1]):
    raise SystemExit("Usage: python scripts/finalize_reserved_doi.py 10.5281/zenodo.XXXXXXXX")
doi=sys.argv[1]
root=Path(__file__).resolve().parents[1]
(root/'metadata/RESERVED_DOI.txt').write_text(doi+'\n',encoding='utf-8')

cff=root/'CITATION.cff'
text=cff.read_text(encoding='utf-8')
if '\ndoi:' not in text:
    text += f'doi: "{doi}"\n'
else:
    text=re.sub(r'(?m)^doi:.*$',f'doi: "{doi}"',text)
cff.write_text(text,encoding='utf-8')

cm=root/'codemeta.json'; data=json.loads(cm.read_text(encoding='utf-8'))
data['identifier']='https://doi.org/'+doi
cm.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

readme=root/'README.md'; text=readme.read_text(encoding='utf-8')
text=text.replace('The exact-version Zenodo DOI is **pending reservation**.',f'The exact-version Zenodo DOI is **{doi}**.')
readme.write_text(text,encoding='utf-8')

tex=root/'article/source/main.tex'; text=tex.read_text(encoding='utf-8')
old='The OPERA-GC review archive is supplied with the submission. Its public repository URL, software license, and exact-version DOI are intentionally not invented in the manuscript and will be inserted after archival deposition.'
new=f'The exact OPERA-GC release used here is archived at Zenodo under DOI \\href{{https://doi.org/{doi}}}{{{doi}}}.'
text=text.replace(old,new)
text=text.replace('Permanent OPERA-GC DOI & To be inserted after archival deposition & pending',f'Permanent OPERA-GC DOI & \\href{{https://doi.org/{doi}}}{{{doi}}} & yes')
tex.write_text(text,encoding='utf-8')
print(f'Inserted reserved DOI {doi}. Recompile the manuscript and rebuild checksums before publication.')
