#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, sys, zipfile
root=Path(__file__).resolve().parents[1]
manifest=root/'MANIFEST.csv'
errors=[]
with manifest.open(newline='',encoding='utf-8') as f:
    for row in csv.DictReader(f):
        p=root/row['path']
        if not p.exists(): errors.append(f"missing: {row['path']}"); continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h != row['sha256']: errors.append(f"hash mismatch: {row['path']}")
        if p.suffix.lower()=='.zip':
            try:
                with zipfile.ZipFile(p) as z:
                    bad=z.testzip()
                    if bad: errors.append(f"zip CRC failure: {row['path']}::{bad}")
            except Exception as exc: errors.append(f"zip open failure: {row['path']}: {exc}")
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('OPERA-GC release verification passed.')
