# Zenodo form values

**Resource type:** Software  
**Title:** OPERA-GC v1.1.0: An operator-aware and selection-preserving framework for heterogeneous globular-cluster proper-motion kinematics  
**Version:** 1.1.0  
**Publication date:** 2026-08-03  
**Language:** English  
**Visibility:** Public  

## Creators

1. Turaev, Sobir J. — ORCID `0000-0002-4932-241X` — Advanced Researches of Astrophysics, Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, Astronomy 33, Tashkent 100052, Uzbekistan
2. Nuritdinov, Salakhutdin N. — ORCID `0000-0002-0743-0981` — Nuclear Physics and Astronomy, National University of Uzbekistan named after Mirzo Ulugbek, University 4, Tashkent 100174, Uzbekistan
3. Yuldoshev, Qudratillo X. — ORCID `0000-0002-6554-3618` — Advanced Researches of Astrophysics, Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, Astronomy 33, Tashkent 100052, Uzbekistan

## Licenses

Add both licenses after all authors approve the policy:

- MIT — original OPERA-GC software and scripts.
- Creative Commons Attribution 4.0 International (CC-BY-4.0) — original documentation, manuscript assets, figures, and derived tables.

Third-party inputs retain their own terms and are documented separately.

## Related identifiers

- `10.17909/jpfd-2m08` — relation: References; resource type: Dataset.
- `10.5281/zenodo.4891252` — relation: References; resource type: Dataset.
- After the journal article receives a DOI, add it with relation `Is documented by` and resource type `Journal article`.

## Funding and communities

Leave blank unless the authors confirm an exact grant identifier or community. Do not invent either field.
