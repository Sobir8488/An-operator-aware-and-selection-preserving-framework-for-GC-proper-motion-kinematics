# Zenodo DOI upload checklist

1. Review `licenses/LICENSE_POLICY.md` and obtain approval from all authors.
2. Create a **New upload** and choose resource type **Software**.
3. Answer **No** to “Does this upload already have a DOI?” and click **Get a DOI now!** to reserve the exact-version DOI.
4. Extract the upload-set ZIP and run `python scripts/finalize_reserved_doi.py <reserved DOI>` inside the full release tree.
5. Recompile `article/source/main.tex` if the DOI should appear in the PDF.
6. Run `python scripts/build_release_artifacts.py` to regenerate checksums and the final release ZIP.
7. Upload the final release ZIP, the preprint PDF, README, CITATION.cff, and SHA256SUMS from the upload set.
8. Copy metadata from `metadata/ZENODO_FORM_VALUES.md`.
9. Add MIT and CC-BY-4.0 as separate licenses only after author approval.
10. Preview the record; verify author order, ORCIDs, version, files, checksums, and related identifiers.
11. Publish. Cite the exact-version DOI in the manuscript and software citation. Use the concept DOI only for an all-versions project link.

Do not publish until the license policy, funding statement, and CRediT roles have been approved by all authors.
