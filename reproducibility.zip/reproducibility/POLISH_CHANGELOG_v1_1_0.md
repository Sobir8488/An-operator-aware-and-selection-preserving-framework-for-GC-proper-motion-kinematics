# OPERA-GC Astronomy and Computing structural polish v1.1.0

## Manuscript architecture

- Rebuilt the paper around an Astronomy and Computing software narrative: journal context, related astronomical workflow systems, design requirements, operator model, implementation architecture, validation design, results, software implications, release, and bounded conclusions.
- Replaced all `enumerate` and `itemize` environments in the manuscript with continuous analytical prose, paragraph-level requirements, or editable tables.
- Moved the complete 12-cluster outer-slope table to an appendix so that the main text emphasizes software validation and claim control.
- Added a related-software comparison table and a predeclared NGC 6397 selection-envelope table.
- Reduced keywords to six journal-focused indexing terms.

## Literature

- Expanded the printed bibliography from 23 to 40 references.
- Added nine papers from Astronomy and Computing, including ORAC-DR, AstroTaverna, Corral, DALiuGE, Docker deployment, Pipeline Collector, the Gaia Archive, Rosetta, and the journal's foundational scope paper.
- Added workflow, container, provenance, research-object, and astronomical cross-identification literature.

## Figures

- Regenerated all main scientific figures as vector PDF plus 450-dpi PNG.
- Increased axes, tick, legend, and annotation typography substantially.
- Replaced the crowded architecture graphic with a clean 2x2 workflow.
- Removed external panel subtitles; concise panel letters remain inside the axes and the captions carry interpretation.
- Reoriented the outer-slope plot horizontally and added both radial and tangential anchor-profile panels.

## Technical verification

- Compiled with `elsarticle` and `elsarticle-harv` without unresolved citations or references.
- Final manuscript: 14 pages, 40 printed references, nine Astronomy and Computing references.
- Rendered and visually inspected every page after compilation.
