# Provenance and release boundary

The release contains only the latest validated package for each production
stage plus the exact frozen output archive used in the manuscript. Historical
hotfix ZIPs and superseded development packages are excluded. Stage 2A retains
a historical frozen-output label `v0.5.0`; its current source package is v0.5.2,
which incorporates the canonical archive-alias resolver. The result archive is
not renamed internally, and both original hashes are recorded in the manifest.

The manuscript is generated from the frozen Stage 1C and Stage 2A–2F outputs.
The stage archives preserve their own configurations, tests, provenance, and
scientific gates.
